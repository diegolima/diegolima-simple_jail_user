##Simple Jail User Puppet Module

This puppet module to create Linux simple jail user with restricted bash.

###How to use


###Contact
Please contact me at rikih dot gunawan at gmail dot com

###Note
No responsibility for any damages relating to its use. Use at your own risk.

